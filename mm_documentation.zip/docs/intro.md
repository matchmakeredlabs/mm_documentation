---
sidebar_position: 1
---

# Introduction

In this documentation, there are a number of words that would benefit from further elaboration. Here, those words are defined in the context of the MatchMaker ecosystem.

---

### **descriptor**

Descriptive metadata for an educational element.

As defined in the MM glossary, an educational element is anything described from an educational perspective.

The overarching term for competency statement or any part of a learning resource, or curriculum.

- **Competency statement**: A statement that describes what a learner will know or be able to do.
- **Learning resource**: An object, content/creative work, or activity that can be used to teach a concept or to assess knowledge of a concept.
- **Curriculum**: An ordering of the competencies and learning resources. The curriculum itself includes the actual scope, sequence, and pedagogical strategies (activities, etc.) to engage students in a learning experience. Curriculum is usually developed for a course or class.

👉 *Read more in [MM’s Glossary](https://docs.google.com/document/d/1hqP94Q-y5FAzl5uhFc6yD__ntmQiwl0r2rkr0S2_w6k/edit?usp=sharing)*

---

### **statements**

These are *Palet™ statements*, MatchMaker’s version of an intermediary statement.

As defined in the MM glossary, an **intermediary** is a collection of intermediary statements, words, or phrases, of different types that can be used to describe educational elements.

- In common parlance, intermediary is considered plural.
- The nature of the structure is not explicitly defined.
- Some flavors of intermediaries explicitly define the structure.

➡️ *MatchMaker Palet™ is an unstructured intermediary.*

---

### **key**

Key refers to an element key, which is made up of the statement IDs of each Palet™ Statement.

A Palet™ is a set of unstructured intermediary statements.

---

### **provenance**

The person or entity that described an educational element.

---

### **hostname**

This will be the host URL for the API.  
At the moment, it is `mm.dciax.org`. However, this will change in the near future.

