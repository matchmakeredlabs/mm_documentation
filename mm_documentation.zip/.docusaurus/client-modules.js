export default [
  require("/Users/aileentang/mm_documentation/node_modules/infima/dist/css/default/default.css"),
  require("/Users/aileentang/mm_documentation/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/Users/aileentang/mm_documentation/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/Users/aileentang/mm_documentation/src/css/custom.css"),
];
